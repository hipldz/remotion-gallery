import {defineConfig} from 'vite';
import {voiceoverPlugin} from '../src/server/index.js';
import {exampleProject} from './project.js';

// Add this plugin alongside the consuming project's existing Vite plugins.
export default defineConfig({
  plugins: [voiceoverPlugin({project: exampleProject, projectRoot: process.cwd()})],
  server: {host: '127.0.0.1'},
});
